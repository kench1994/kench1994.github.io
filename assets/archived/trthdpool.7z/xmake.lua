set_version("3.50.230822", {build = "%Y-%m-%d %H:%M"})

add_rules("mode.debug", "mode.release", "mode.releasedbg")
includes("./xmake/__platform.lua", "./xmake/__devLibs_trdlp.lua")
load_platform_cfg()
set_installdir("./build/$(plat)/$(arch)/$(mode)")

g_vs_runtime = "MDd"
if not is_mode("release") then
    g_vs_runtime = "MD"
end
add_requires("DlpULog", "trcrt")
add_requires("trfclib", {configs = {vs_runtime = g_vs_runtime}})

target("TrThreadPool")
    set_kind("shared")
	set_optimize("fastest")
    add_packages("trfclib")
    add_defines("TR_THREAD_POOL_EXPORTS", "TR_THREAD_ENABLE_SHARED_TRAIT");
	add_includedirs(".")
    add_files("src/*.cpp")
    add_options("dynamic_library_cfg")

	if is_plat("windows") then
		add_configfiles("src/TrThreadPool.rc.in", {filename = "../src/TrThreadPool.rc"})
		add_files("src/*.rc")
	end
target_end()

target("demo")
    add_deps("TrThreadPool")
    add_includedirs("src", ".")
    add_files("demo.cpp")
	add_defines("TR_THREAD_ENABLE_SHARED_TRAIT")
    add_linkdirs("$(scriptdir)/build/$(host)/$(arch)/$(mode)")
    -- add_links("TrThreadPool")
    add_options("excutable_cfg")
    add_packages("trfclib", "DlpULog", "trcrt")
	if is_plat("windows") then
		set_pcxxheader("targetver.h")
	end
    -- 自动生成 compile_commands.json 帮助代码补全跳转
    after_build(function (target)
        import("core.base.task")
        task.run("project", {kind = "compile_commands", outputdir = ".vscode"})
    end)
target_end()

after_install(function (target)
	for _,v in ipairs({"./build/$(plat)/$(arch)/$(mode)/libs_x64", "./build/$(plat)/$(arch)/$(mode)/config"}) do
		if not os.exists(v) then
			os.mkdir(v)
		end
	end
    os.mv("./build/$(plat)/$(arch)/$(mode)/lib/*", "./build/$(plat)/$(arch)/$(mode)/libs_x64")
	os.cp("./config/*", "./build/$(plat)/$(arch)/$(mode)/config")
	for _,v in ipairs({"./build/$(plat)/$(arch)/$(mode)/lib/", "./build/$(plat)/$(arch)/$(mode)/bin/", "./build/$(plat)/$(arch)/$(mode)/include/",  "./build/$(plat)/$(arch)/$(mode)/libs_x64/libTrThreadPool.so"}) do 
		os.rm(v);
	end
end)


on_package(function (target)
	if is_mode("releasedbg") then
		local package_dir = "$(projectdir)/build/packages"
		local demo_src_dir = path.join(package_dir, "demo");
		for _,v in ipairs({package_dir, demo_src_dir}) do
			os.mkdir(v)
		end
		for _, plat in ipairs({ "linux64", "win32" }) do
			os.mkdir(path.join(package_dir, plat))
			os.mkdir(path.join(package_dir, plat, "demo"))
		end
		os.cp("$(projectdir)/demo.cpp", demo_src_dir)

		os.cp("$(projectdir)/interface/", package_dir)
		local lib_dir = ""
		local demo_dir = ""
		local plat_arch = ""
		if not is_plat("windows") then
			plat_arch = "linux64"
		else
			plat_arch = "win32"
		end
		lib_dir = path.join(package_dir, plat_arch, "lib")
		demo_dir = path.join(package_dir, plat_arch, "demo")
		for _,v in ipairs({lib_dir, demo_dir}) do
			os.mkdir(v)
		end
		os.cp(target:targetfile(), demo_dir)
		os.cp("$(projectdir)/config", demo_dir)
		if target:basename() ~= "demo" then
			os.cp(target:targetfile(), lib_dir)
		end
	else
		cprint("${red}%s${reset}", "current mode not correct!")
		print("")
	end
end)

-- 如果需要debug版本使用 {configs = {debug = true}}
-- add_requires("trfclib", {configs = {vs_runtime = "MT"}})
-- target("trfclib-mt")
--     add_packages("trfclib")
--     add_files("demo.cpp")
-- target_end()

-- target("TrThreadPool")
--     set_kind("shared")
--     add_defines("TR_THREAD_POOL_EXPORTS");
--     add_packages("trfclib")
--     add_files("src/TrThreadPool.cpp")
--     add_syslinks("pthread")
--     add_options("dynamic_library_cfg")
-- target_end()