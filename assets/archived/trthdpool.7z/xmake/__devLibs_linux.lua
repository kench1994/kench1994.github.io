package("ltdl")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = package:name(),
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()

package("odbcinst")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    if is_arch("arm64-v8a") then
        add_deps("ltdl")
    end
    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so.2"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = ":" .. libfile,
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()

package("dmdpi")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = package:name(),
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()

package("dcikdb")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    add_deps("odbcinst", "ssl", "pq")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = package:name(),
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()