if not is_plat("windows") then
    includes("__devLibs_linux.lua")
end

package("trcrt")
    set_description("Tipray trcrt")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    on_fetch(function (package)
        import("lib.detect.find_path")
        import("lib.detect.find_library")
        local result = {}
        result.includedirs = find_path(package:name() , path.join(package:sourcedir(), "inc"))
        result.links = package:name() 
        if not is_host("windows") then
            local arch_dir = "x86_64"
            if is_arch("arm64-v8a") then
                arch_dir = "aarch64"
            end
            local libfile = "lib" .. package:name()  .. ".so"
            result.linkdirs =  find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64"))
            result.libfiles = path.join(result.linkdirs, libfile)
        else
            result.linkdirs = find_path(package:name() .. ".lib", path.join(package:sourcedir(), "libs"))
            local dll = find_library(package:name(), path.join(package:sourcedir(), "dll", package:name()))
            result.libfiles = path.join(dll["linkdir"], dll["filename"])
        end
        return result
    end)
package_end()

package("trfclib")
    set_description("trfclib")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    add_configs("vs_runtime", {description = "Set vs compiler runtime.", default = "MDd", readonly = false})
    if not is_host("windows") then
        add_syslinks("pthread")
    end
    on_fetch(function (package)
        import("lib.detect.find_path")
        local result = {}
        result.shared = false
        result.pic = true
        result.includedirs = find_path(package:name() , path.join(package:sourcedir(), "inc"))
        if not is_host("windows") then
            local arch_dir = "x86_64"
            if is_arch("arm64-v8a") then
               arch_dir = "aarch64"
            end
            result.links = package:name()
            result.linkdirs = find_path("lib" .. package:name() .. ".a", path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64"))
        else
            if package:config("vs_runtime") then
                result.links =  package:name()  .. "_" .. string.lower(package:config("vs_runtime"))
                result.linkdirs = find_path(result.links .. ".lib", path.join(package:sourcedir(), "libs"))
            end

            -- if not package:config("vs_runtime"):startswith("MT") then
            --     result.links = package:name()  .. (package:debug() and "_mdd" or "_md")
            -- else
            --     result.links = package:name()  .. (package:debug() and "_mtd" or "_mt")
            -- end
            -- result.linkdirs = find_path(package:name() .. ".lib", path.join(package:sourcedir(), "libs"))
        end
        return result
    end)
package_end()

package("DlpULog")
    set_description("Tipray DlpULog")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64"))
        return {
            includedirs = find_path(package:name() , path.join(package:sourcedir(), "inc")),
            linkdirs = libdir, 
            links = package:name(), 
            libfiles = path.join(libdir, libfile)
        }
    end)
    on_fetch("windows", function (package) 
        import("lib.detect.find_path")
        local dlldir = find_path(package:name(), path.join(package:sourcedir(), "dll"))
        return {
            includedirs = find_path(package:name(), path.join(package:sourcedir(), "inc")),
            linkdirs = find_path(package:name() .. ".lib", path.join(package:sourcedir(), "libs")),
            links = package:name(),
            libfiles = path.join(dlldir, package:name(), package:name() .. ".dll")
        }
    end)
package_end()

package("boost-1.58.0")
    set_description("boost 1.58.0 which contains boost_system for trcomm")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    on_fetch("mingw", "linux", "macosx", function (package) 
        import("lib.detect.find_path")
        local lib = "libboost_system.so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(lib, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))
        
        local result = {
            linkdirs = libdir,
            links = "boost_system", 
            libfiles = { path.join(libdir, lib),  path.join(libdir, "libboost_system.so.1.58.0") }
        }
        return result
    end)
package_end()

package("trcomm")
    set_description("Tipray Communication Component")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    --声明依赖boost
    add_deps("DlpULog")
    --if not is_host("windows") then
    if is_arch("x86_64") then
        add_deps("boost-1.58.0")
    end
    on_fetch("linux", function (package) 
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64")
        local libfiles = {}
        local links = {"trdevppf", "trnetbcm"}
        for _,lib in ipairs(links) do
            table.insert(libfiles, path.join(libdir, "lib" .. lib .. ".so"))
        end
        return {
            linkdirs = libdir, 
            links = links,
            libfiles = libfiles
        }
    end)
    on_fetch("windows", function (package) 
        import("lib.detect.find_path")
        local dlldir = find_path(package:name(), path.join(package:sourcedir(), "dll"))
        local dllfiles = {}
        for _,dll in ipairs({"trdevppf", "trnetbcm"}) do
            table.insert(dllfiles, path.join(dlldir, package:name(), dll .. ".dll"))
            table.insert(dllfiles, path.join(dlldir, package:name(), dll .. ".pdb"))
        end

        return {
            includedirs = find_path(package:name(), path.join(package:sourcedir(), "inc")),
            libfiles = dllfiles
        }
    end)
package_end()

package("trsigar")
    set_description("Tipray System Information Gatherer And Reporter")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    add_deps("DlpULog")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local lib_name = "TrSigar"
        local libfile = "lib" .. lib_name .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64"))
        return {
            includedirs = find_path( lib_name , path.join(package:sourcedir(), "inc")),
            linkdirs = libdir, 
            links = lib_name, 
            libfiles = path.join(libdir, libfile)
        }
    end)
    on_fetch("windows", function (package) 
        import("lib.detect.find_path")
        local lib_name = "TrSigar"
        local dlldir = find_path(lib_name, path.join(package:sourcedir(), "dll"))
        return {
            includedirs = find_path( package:name(), path.join(package:sourcedir(), "inc")),
            linkdirs = find_path(lib_name .. ".lib", path.join(package:sourcedir(), "libs")),
            links = lib_name,
            libfiles = path.join(dlldir, lib_name, lib_name .. ".dll")
        }
    end)
package_end()

package("pq")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so.5"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = ":" .. libfile,
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()

package("z")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so"
        local arch_dir = "x86_64"
        local postfix = ".1.2.12"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
            postfix = ".1.2.11"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))
        local libfiles = {}
        table.insert(libfiles, path.join(libdir, libfile))
        table.insert(libfiles, path.join(libdir, libfile .. ".1"))
        table.insert(libfiles, path.join(libdir, libfile .. postfix))
        return {
            linkdirs = libdir,
            links = package:name(),
            libfiles = libfiles
        }
    end) 
package_end()

package("crypto")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    add_deps("z")
    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so.10"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = ":" .. libfile,
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()

package("ssl")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    add_deps("crypto")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so.10"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            linkdirs = libdir,
            links = ":" .. libfile,
            libfiles = path.join(libdir, libfile)
        }
    end) 
package_end()

package("mysqlclient")
    set_description("Mysql Client Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")

    on_fetch("windows", function (package) 
        import("lib.detect.find_path")
        local dlldir = find_path("libmysql.dll", path.join(package:sourcedir(), "dll", "trdb"))
        return {
            linkdirs = path.join("libmysql.lib", "libs"),
            links = "libmysql",
            libfiles = path.join(dlldir, "libmysql.dll")
        }
    end)

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfiles = {}
        local libfile = "lib" .. package:name() .. ".so"
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", "x86_64", "lib3rds_x64"))

        table.insert(libfiles, path.join(libdir, libfile))
        table.insert(libfiles, path.join(libdir, libfile .. ".18"))
        table.insert(libfiles, path.join(libdir, libfile .. ".18.4"))

        return {
            linkdirs = libdir,
            links = package:name(),
            libfiles = libfiles
        }
    end) 
package_end()

package("trdb")
    set_description("Tipray Database Operation Library")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    if is_plat("windows") then
        add_deps("mysqlclient", "DlpULog")
    else
        if is_arch("arm64-v8a") then
            add_deps("dcikdb", "DlpULog")
        else
            add_deps("mysqlclient", "dcikdb", "dmdpi", "DlpULog")
        end
    end
    add_deps("DlpULog")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local lib_name = "trdbdal"
        local libfile = "lib" .. lib_name .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64"))
        local lib3rd_dir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "lib3rds_x64"))

        return {
            includedirs = find_path( lib_name , path.join(package:sourcedir(), "inc")),
            linkdirs = libdir,
            links = lib_name,
            libfiles = path.join(libdir, libfile)
        }
    end)
    on_fetch("windows", function (package) 
        import("lib.detect.find_path")
        local lib_name = "trdbdal"
        local dlldir = find_path(package:name(), path.join(package:sourcedir(), "dll"))
        return {
            includedirs = find_path( package:name(), path.join(package:sourcedir(), "inc")),
            linkdirs = find_path(lib_name .. ".lib", path.join(package:sourcedir(), "libs")),
            links = lib_name,
            libfiles = path.join(dlldir, package:name(), lib_name .. ".dll")
        }
    end)
package_end()

package("curl")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        return {
            includedirs = find_path(package:name() , path.join(package:sourcedir(), "inc"))
        }
    end)
package_end()

package("trRemoteGrap")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    add_deps("DlpULog")

    on_fetch("linux", function (package) 
        import("lib.detect.find_path")
        local libfile = "lib" .. package:name() .. ".so"
        local arch_dir = "x86_64"
        if is_arch("arm64-v8a") then
            arch_dir = "aarch64"
        end
        local libdir = find_path(libfile, path.join(package:sourcedir(), "libs_4linux", arch_dir, "libs_x64"))
        return {
            includedirs = find_path( package:name() , path.join(package:sourcedir(), "inc")),
            linkdirs = libdir, 
            links = package:name(), 
            libfiles = path.join(libdir, libfile)
        }
    end)
    on_fetch("windows", function (package) 
        import("lib.detect.find_path")
        local dlldir = find_path(package:name() .. ".dll", path.join(package:sourcedir(), "dll", "trremote"))
        return {
            includedirs = find_path( package:name(), path.join(package:sourcedir(), "inc")),
            linkdirs = find_path(package:name() .. ".lib", path.join(package:sourcedir(), "libs")),
            links = package:name(),
            libfiles = path.join(dlldir, package:name() .. ".dll")
        }
    end)
package_end()


package("rapidjson")
    set_sourcedir("$(projectdir)/../../__devLibs_trdlp")
    on_fetch(function (package) 
        import("lib.detect.find_path")
        return {
            includedirs = find_path(package:name() , path.join(package:sourcedir(), "inc"))
        }
    end)
package_end()
