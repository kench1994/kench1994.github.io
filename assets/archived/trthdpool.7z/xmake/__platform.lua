function load_platform_cfg()
    -- 有几个内置的模式, debug、release、releasedbg（携带调试符号的优化release版本）
    -- 模式需要通过 xmake f -m $mode 切换
    add_rules("mode.debug", "mode.releasedbg", "mode.release")
    if not is_mode("debug") then
        -- 不要用到O3,O2就好
        set_optimize("faster")
    end
    -- 开启 c++ 异常
    set_exceptions("cxx")
    if is_plat("windows") then
        --set_optimize("faster")
        add_defines("WIN32", "_WIN32", "_WINDOWS", "_CRT_SECURE_NO_DEPRECATE")
        add_defines("_UNICODE" ,"UNICODE")
        set_languages("cxx14")
        set_config("arch", "x86")
        add_cxflags("/utf-8")
        set_runtimes(is_mode("debug") and "MDd" or "MD")
        -- 从 vs 抄的一些编译参数
        -- 释义参考 https://zhuanlan.zhihu.com/p/434454915
        add_ldflags(
            "/MANIFEST",
            "/LTCG:incremental",
            "/NXCOMPAT",
            "/DYNAMICBASE",
            "/OPT:REF",
            "/SAFESEH",
            "/INCREMENTAL:NO",
            "/ERRORREPORT:PROMPT",
            "/NOLOGO", {force = true}
        )
        add_cxxflags("/Zc:inline", "/Zc:threadSafeInit", "/Zc:forScope", "/Zc:wchar_t", "/GS", {force = true})
    else
        set_languages("cxx11")
        set_config("arch", "x86_64")
        set_strip("none")
        --set_strip("debug")
        add_cxxflags("-fPIC", "-fvisibility=hidden")
    end
end

option("dynamic_library_cfg")
    set_default(true)
    if not is_plat("windows") then
        add_shflags("-Wl,-rpath,./:./lib3rds_x64:./libs_x64:../lib3rds_x64:../libs_x64")
        add_shflags("-Wl,--no-undefined", "-Wl,--exclude-libs,ALL", "-Wl,-Bsymbolic")
        --链接一些额外的系统库,其实不一定所有的都需要pthread或dl,就是说写着影响不大
        add_syslinks("dl", "pthread")
    else 
        add_defines("_USRDLL", "_DLL", "_WINDLL")
        add_shflags(
            "/MANIFEST",
            "/LTCG:incremental",
            "/NXCOMPAT",
            "/DYNAMICBASE",
            "/OPT:REF",
            "/SAFESEH",
            "/INCREMENTAL:NO",
            "/ERRORREPORT:PROMPT",
            "/NOLOGO", {force = true}
        )
    end
option_end()

option("excutable_cfg")
    set_default(true)
    if not is_plat("windows") then
        add_ldflags("-Wl,-rpath,./:./lib3rds_x64:./libs_x64:../lib3rds_x64:../libs_x64")
        add_ldflags("-Wl,--no-undefined", "-Wl,--exclude-libs,ALL", "-Wl,-Bsymbolic")
        --链接一些额外的系统库
        add_syslinks("dl", "pthread")
    end
option_end()