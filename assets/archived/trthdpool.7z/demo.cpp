#include "interface/TrThreadPool.h"
#include <functional>
#include <string.h>
#include <iostream>
#include <thread>
#include <chrono>
#include <memory>
#include <ctime>
#include <trcrt/trcrt.h>
#include <DlpULog/DlpULog.h>

inline std::string time_now(const char* pszFormat = "%H:%M:%S")
{
	time_t now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
	struct tm tm_now;
#ifdef _WIN32
	localtime_s(&tm_now, &now);
#else
	localtime_r(&now, &tm_now);
#endif
	char szTimeBuf[32]{'\0'};
	std::strftime(szTimeBuf, sizeof(szTimeBuf), pszFormat, &tm_now);
	return szTimeBuf;
}

int initLogComponent()
{
    //初始化日志组件
    char szLogConfigDir[1024] = {0};
    trcrt::app::tr_app_get_config_directory( \
		szLogConfigDir, sizeof(szLogConfigDir) - 1 \
	);
	trcrt::path::tr_path_make_sub_path( \
		szLogConfigDir, \
		1024 - strlen(szLogConfigDir), \
		"log_TrCSrvcore.properties"
	);
    int res = dlplog_load_config(szLogConfigDir);
    if (res != 0) {
        fprintf(stderr, "dlplog_load_config(%s) failed:%d", szLogConfigDir, res);
        return -1;
    }
    dlplog_init(__FILE__);
    dlplog_open(__FILE__);
    return 0;
}


class Task 
 : public tr::threadEx::IExcutor 
{
public:
	Task() = delete;

	Task(const char* szMsg)
	{ snprintf(szBuffer, strlen(szMsg), szMsg);	}

	virtual ~Task() { 	printf("destruction Task <%p>\r\n", std::addressof(this));}

	void routine(const uint8_t) override
	{ printf("\r\n%s\r\nroutine from cxx interface\r\n", szBuffer); }

private:
	//我是觉得用上类了,数据可以自己携带
	char szBuffer[1024];
};


int main()
{
#ifdef _WIN32
	SetConsoleOutputCP(65001);
#endif
	trcrt::trcrt_init();
    //加载日志组件
    initLogComponent();

	tr::threadEx::TrdPoolOption_s tp_opt;
	tr::threadEx::ThreadPool tp(tp_opt);
	tp.initNotStart();
	tp.startUp();

	//c++ style 1
	{
		tp.submit_cxx(new Task("Hello,World!"), [](tr::threadEx::IExcutor* work_excutor){
			if(!work_excutor)
				return;
			printf("delete work_excutor <%p>\r\n", std::addressof(work_excutor));
			delete work_excutor;
		});
	}
	
	//c-style 1
	{
		char* pWelcome = new char[1024]{0x00};
		snprintf(pWelcome, strlen("こんにちは,世界!"), "こんにちは,世界!");
		tp.submit(
			[](const uint8_t ec, void* user_data){
				char* buffer = static_cast<char*>(user_data);
				printf("%s\r\n", buffer);
			}, 
			pWelcome, 
			[](void* user_data){ 
				if(!user_data) return;
				char* buffer = static_cast<char*>(user_data);
				printf("delete heap_data <%p>\r\n", std::addressof(buffer));
				delete []buffer;
			}
		);
	}

	//c++ style 2
	{
		auto spTask = std::make_shared<Task>("嘿,别来无恙!");
		tp.submit_shared_cxx(spTask);
	}

	//mix style
	for(auto n = 0;n<1024;n++)
	{
		std::shared_ptr<char> spWelcome(new char[1024], std::default_delete<char[]>());
		sprintf(spWelcome.get(), "Hola, mundo! This is %d task.", n);

		tr::threadEx::tagThreadTaskOption opt;
		opt.notify_on_destruction = true;
		tp.submit_shared_data(\
			[](const uint8_t ec, std::shared_ptr<void>& user_data_sp) {
				if(ec)
				{
					printf("%p not schedule\r\n", std::addressof(user_data_sp));
					return;
				}
				if (!user_data_sp) return;
				auto spData = std::static_pointer_cast<char>(user_data_sp);
				printf("%s\r\n", spData.get());
			},
			std::static_pointer_cast<void>(spWelcome), &opt
		);
	}

	//once reactor模式,适用于先投递完有限量任务然后启动,主线程会阻塞到所有任务完成
	tr::threadEx::TrdPoolOption_s reactor_opt(4, true, true);
	tr::threadEx::ThreadPool tp_reactor(reactor_opt);
	{
		tp_reactor.initNotStart();
		for(int i = 0; i < 10240; i++)
		{
			tp_reactor.submit_shared_data(\
				[](const uint8_t ec, std::shared_ptr<void>& user_data_sp) {
					if(ec)
					{
						printf("%p not schedule\r\n", std::addressof(user_data_sp));
						return;
					}
					if (!user_data_sp) return;
					auto spData = std::static_pointer_cast<int>(user_data_sp);
					printf("once reactor work %d done!\r\n", *spData);
				},
				std::make_shared<int>(i)
			);
		}
		tp_reactor.startUp();
	}
	
	//interrupt task sample
	//a try,stop tasks while exec time exceed
	{
		typedef struct tagTaskCtx{
			int user_data {0};
			tr::threadEx::ThreadPool* pool_ptr_watch {nullptr};
			std::chrono::steady_clock::time_point start_time_point {std::chrono::steady_clock::now()};
		}TaskCtx_s;
		for(int i = 0; i < 16; i++)
		{
			auto spIntPackageTask = std::make_shared<TaskCtx_s>();
			spIntPackageTask->user_data = i;
			spIntPackageTask->pool_ptr_watch = &tp_reactor;

			tp_reactor.submit_shared_data(\
				[](const uint8_t ec, std::shared_ptr<void>& user_data_sp) {
					if(ec)
					{
						printf("%p not schedule\r\n", std::addressof(user_data_sp));
						return;
					}
					//simulate busy work
					std::this_thread::sleep_for(std::chrono::seconds(3));

					if (!user_data_sp) return;
					auto spIntPackageTask = std::static_pointer_cast<TaskCtx_s>(user_data_sp);
					printf("[%s]once reactor work %d done!\r\n", time_now().c_str(), spIntPackageTask->user_data);

					std::chrono::steady_clock::time_point finish_time_point = std::chrono::steady_clock::now();
					if(6 <= std::chrono::duration_cast<std::chrono::seconds>(finish_time_point - spIntPackageTask->start_time_point).count())
					{
						spIntPackageTask->pool_ptr_watch->stop();
						printf("exec overtime, stop work!\r\n");
					}
				},
				spIntPackageTask
			);
		}
		//once reactor 模式下下允许startUp重入
		tp_reactor.startUp();
	}

	printf("按q退出等待!\r\n");
    while (1) //等待信号结束主线程
    {
		char q;
		q = getchar();
        if('q' == q)
            break;
    }
    return 0;
}