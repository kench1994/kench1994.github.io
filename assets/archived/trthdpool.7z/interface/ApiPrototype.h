/**
 * @copyright Copyright (c) 2023 厦门天锐科技股份有限公司
 * @brief    线程池回调函数原型
 * @author   huangchao
 * @version  1.0
 * @date     2023-07-07
 * 
 */
#pragma once
#include <inttypes.h>

#ifndef CALLBACK
#  if defined(_MSC_VER) || defined(_WIN32)
#    include <windows.h> // for introduce callback
#  else
#    define CALLBACK
#  endif
#endif

#ifndef __cplusplus
#  include <stdbool.h>

#else
#  include <string.h>
#  include <memory>		// for introduce shared_ptr
#  include <thread>
namespace tr
{
	namespace threadEx
	{
		/**
		 * @brief  调度接口类
		 */
        class IExcutor
        {
            public:
                virtual ~IExcutor() {}

                virtual void routine(const uint8_t error_code) = 0;
        };
#endif
#ifdef __cplusplus
		enum class kTrdPoolError : uint8_t
#else
		enum kTrdPoolError 
#endif
		{
			no_error = 0,
			
			//整体资源退出,交由用户处理{一般是用户完全不保存该数据的情况}
			unschedule = 0xfd,

			unknown_error = 0xfe
		};

		typedef struct tagThreadPoolOption
		{
			tagThreadPoolOption() : 
				pool_size(std::thread::hardware_concurrency()), 
				enable_cpu_affinity(false), 
				once_reactor_mode(false)
			{}
			tagThreadPoolOption(unsigned int pool_cnt, bool cpu_affinity, bool once_reactor) :
				pool_size(pool_cnt), 
				enable_cpu_affinity(cpu_affinity), 
				once_reactor_mode(once_reactor)
			{}
			unsigned int pool_size;
			bool enable_cpu_affinity; 
			bool once_reactor_mode;
		}TrdPoolOption_s;

		typedef struct tagThreadTaskOption
		{
			tagThreadTaskOption(){ memset(this, 0x00, sizeof(tagThreadTaskOption)); }
			//指定线程投递id,-1时表示使用round-robin调度算法
			int  thread_idx;
			//标识任务能否被窃取
			bool can_steal;
			//较快执行
			bool immediately;
			//线程池析构时强制该任务还未被调度强制通知到用户
			//慎用,堆积任务过多时会影响组件析构速度
			bool notify_on_destruction;
		}TrdTaskOption_s;

		/*c回调函数原型*/
		typedef void (CALLBACK *trThreadEx_CExcutor_t)(const uint8_t error_code, void* user_data);

#ifdef TR_THREAD_ENABLE_SHARED_TRAIT
		/*c回调函数原型v2 user_data为智能指针，通常是用户不想额外容器掌管user_data生命周期*/
		typedef void (CALLBACK *trThreadEx_AutoExcutor_t)(const uint8_t error_code, std::shared_ptr<void>& user_data);
#endif

		/*堆上void* 销毁函数原型*/
		typedef void (CALLBACK *trThreadEx_FreeHeapData_t)(void* user_data);

#ifdef __cplusplus
		/*调度接口实例销毁 函数原型*/
		typedef void (CALLBACK *trThreadEx_IExcutorDeleter_t)(IExcutor* work_excutor);

	}
}
#endif