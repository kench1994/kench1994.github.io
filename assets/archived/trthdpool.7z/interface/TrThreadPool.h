#pragma once
#if defined(_MSC_VER) || defined(_WIN32)
#  ifdef  TR_THREAD_POOL_EXPORTS
#    define TR_THREAD_POOL_API __declspec(dllexport)
#  else
#    define TR_THREAD_POOL_API __declspec(dllimport)
#  endif
#elif defined(__GNUC__)
#  ifdef __cplusplus
#    define TR_THREAD_POOL_API __attribute__ ((visibility("default")))
#  else
    #define TR_THREAD_POOL_API
#  endif
#endif
#include "ApiPrototype.h"

namespace tr
{
    namespace threadEx
    {
        class ThreadPool
        {
            public:
                TR_THREAD_POOL_API ThreadPool() = delete;
				/**
				 * @brief  线程池构造函数
				 * @param  pool_size        线程池大小
				 * @param  cpu_affinity     是否开启cpu亲和性
				 */
                TR_THREAD_POOL_API ThreadPool(const TrdPoolOption_s& opt);
				//禁止拷贝构造
                TR_THREAD_POOL_API ThreadPool(ThreadPool&) = delete;
				//禁止拷贝
                TR_THREAD_POOL_API ThreadPool& operator=(ThreadPool&) = delete;
                TR_THREAD_POOL_API virtual ~ThreadPool();

                TR_THREAD_POOL_API int  initNotStart();
                TR_THREAD_POOL_API int  startUp();
                TR_THREAD_POOL_API void stop();
                TR_THREAD_POOL_API void release();
				

				/**
				 * @brief  c回调任务投递接口
				* @param worker			回调函数
				* @param user_data	    用户传递数据
				* @param free_allocator	如果用户数据为new、malloc建立,可以通过传递该回调有线程池在调度结束后进行销毁,放在接口规范用户编程
				* @param option			任务选项,详看ApiPrototype.h定义
				 */
				TR_THREAD_POOL_API int submit(
					trThreadEx_CExcutor_t worker, \
					void* user_data, \
					trThreadEx_FreeHeapData_t free_allocator = NULL,
					const TrdTaskOption_s* option = NULL
				);

				/**
				 * @brief  c++虚函数任务投递接口(类自身就可以携带很多数据了,所以目前没有额外的user_data)
				* @param work_excutor		调度类句柄
				* @param excutor_deleter	如果调度类为临时堆上变量,可通过传递该接口进行资源销毁
				* @param option				任务选项,详看ApiPrototype.h定义
				 */
                TR_THREAD_POOL_API int submit_cxx(
					IExcutor* work_excutor, \
					trThreadEx_IExcutorDeleter_t excutor_deleter = NULL,
					const TrdTaskOption_s* option = NULL
				);

				//一些针对智能指针的解决方案
				//user_data使用智能指针包裹
				TR_THREAD_POOL_API int submit_shared_data(
					trThreadEx_AutoExcutor_t worker, 
					std::shared_ptr<void> user_data,\
				 	const TrdTaskOption_s* option = NULL
				);

				//调度类使用智能指针包裹
				TR_THREAD_POOL_API int submit_shared_cxx(
					std::shared_ptr<IExcutor> work_excutor,
					const TrdTaskOption_s* option = NULL
				);

            private:
                class ThreadPoolImpl;
                ThreadPoolImpl* m_pTrdPoolImpl;
        };
    }
}