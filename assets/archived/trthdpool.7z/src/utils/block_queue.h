#pragma once
#include <mutex>
#include <queue>
#include <deque>
#include <memory>
#include <thread>
#include <condition_variable>
namespace utils
{
    template<typename T>
    class concurrency_queue
    {
    public:
        using queue_type = std::deque<T>;

        concurrency_queue()
        {
        }

        ~concurrency_queue()
        {
            
        }

        void push_back(const T& x)
        {
			std::lock_guard<std::mutex> lock(m_mtx);
			m_queue.push_back(x);
			m_Condit.notify_one();
        }

        void emplace_back(T&& x)
        {
            std::lock_guard<std::mutex> lock(m_mtx);
            m_queue.emplace_back(std::forward<T&&>(x));
            m_Condit.notify_one();
        }

		void push_front(const T& x)
		{
			std::lock_guard<std::mutex> lock(m_mtx);
			m_queue.push_front(x);
			m_Condit.notify_one();
		}

		void emplace_front(T&& x)
		{
			std::lock_guard<std::mutex> lock(m_mtx);
			m_queue.emplace_front(std::forward<T&&>(x));
			m_Condit.notify_one();
		}

		T pop_front()
		{
			std::lock_guard<std::mutex> lock(m_mtx);
			if (m_queue.empty())
				return NULL;
			T front(std::move(m_queue.front()));
			m_queue.pop_front();

			return front;
		}

        T wait_and_pop()
        {
            std::unique_lock<std::mutex> lock(m_mtx);
            if(m_queue.empty())
                m_Condit.wait(lock);

			//意外唤醒
			if(m_queue.empty())
				return NULL;

            T front(std::move(m_queue.front()));
            m_queue.pop_front();
			lock.unlock();

            return front;
        }
		

		T wait_and_pop_t(int millisecond)
		{
            std::unique_lock<std::mutex> lock(m_mtx);
            if(m_queue.empty())
			{
				auto wait_status = m_Condit.wait_for(lock, std::chrono::milliseconds(millisecond));
				if(std::cv_status::timeout == wait_status)
					return NULL;
			}

			//意外唤醒
			if(m_queue.empty())
				return NULL;

            T front(std::move(m_queue.front()));
            m_queue.pop_front();
			return front;
		}

		T try_pop_if(bool (*predict)(const T &) = NULL) 
		{
			std::unique_lock<std::mutex> lock(m_mtx, std::try_to_lock);
			if (!lock || m_queue.empty())
				return NULL;

			if (NULL != predict && !predict(m_queue.front())) 
			{
				return NULL;
			}

            T front(std::move(m_queue.front()));
			m_queue.pop_front();
			lock.unlock();

            return front;
		}

        queue_type drain()
        {
            queue_type queue;
            {
                std::lock_guard<std::mutex> lock(m_mtx);
                queue = std::move(m_queue);
            }
            return queue;
        }

        bool empty() const
        {
            std::lock_guard<std::mutex> lock(m_mtx);
            return m_queue.empty();
        }

		void notify_all()
		{
			std::lock_guard<std::mutex> lock(m_mtx);
			m_Condit.notify_all();
		}

    private:
        std::condition_variable m_Condit;
        mutable std::mutex m_mtx;
        queue_type m_queue;
    };
}