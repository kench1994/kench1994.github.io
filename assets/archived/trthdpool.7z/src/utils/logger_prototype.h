#ifdef _WIN32
#  include <windows.h>
#else
#  define WINAPI
#endif

typedef int (WINAPI *dlplog_open_v2_t)(const char* log_name, char const* module_name);
typedef void (WINAPI *dlplog_t)(int log_handle, char const* format_str, ...);