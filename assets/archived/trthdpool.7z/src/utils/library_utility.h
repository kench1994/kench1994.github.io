#pragma once

#if defined(_WIN32)
#elif defined(__GNUC__)
#  include <dlfcn.h>
#endif
#if defined(_WIN32)
	typedef HMODULE shared_library_t;
#elif defined(__GNUC__)
   typedef void*   shared_library_t;
#endif

namespace utils
{
	namespace shared_library
	{

		inline void* symbol_addr(shared_library_t hwnd, const char* fn_name_strz)
		{
			//判断动态库加载
		#if defined(_WIN32)
			if (NULL == hwnd) return NULL;
		#elif defined(__GNUC__)
			if (NULL == hwnd) return NULL;
		#else
		#pragma message("non-win32 and non-GUNC,Unsupported!")
			return NULL;
		#endif

			void* symbol = NULL;

		#if defined(_WIN32)
			symbol = (void*)GetProcAddress(hwnd, fn_name_strz);
		#elif defined(__GNUC__)
			symbol = dlsym(hwnd, fn_name_strz);
		#else
			symbol = NULL;
		#endif
			return symbol;
		}
	}
	
} 
