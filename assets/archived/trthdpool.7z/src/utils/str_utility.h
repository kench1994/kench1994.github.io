#pragma once
#include <limits.h>
#include <string.h>
namespace utils
{
	namespace str
	{
		template<class... Args>
		int cross_sprintf(char* o_szBuffer, size_t max_buffer_len, const char* v_szFormat, Args&&... args)
		{
			int nRet = 0;
		#ifdef _WIN32
			nRet = sprintf_s(o_szBuffer, max_buffer_len, v_szFormat, std::forward<Args>(args)...);
		#elif defined(__GNUC__)
			nRet = snprintf(o_szBuffer, max_buffer_len, v_szFormat, std::forward<Args>(args)...);
		#endif
			return nRet;
		}
	}
}