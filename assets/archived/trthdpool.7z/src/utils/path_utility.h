#pragma once
#include <string.h>
#ifndef _WIN32
#  include <unistd.h>
#endif
namespace utils
{
	namespace path
	{
		inline bool get_app_path(char* sz_path_buffer, size_t buffer_len)
		{
#ifdef _WIN32
			GetModuleFileNameA(NULL, sz_path_buffer, buffer_len);
			std::string strPathBuffer(sz_path_buffer);
			auto nPos = strPathBuffer.find_last_of("\\");
			if (std::string::npos == nPos)
				return true;
			strPathBuffer.erase(nPos);
			sprintf_s(sz_path_buffer, buffer_len, strPathBuffer.c_str());
#else
			//获取当前程序绝对路径
			int cnt = readlink("/proc/self/exe", sz_path_buffer, buffer_len);
			if (cnt < 0 || cnt >= 1023)
			{
				return false;
			}
			//获取当前目录绝对路径，即去掉程序名
			for (int i = cnt; i >= 0; --i)
			{
				if (sz_path_buffer[i] == '/')
				{
					sz_path_buffer[i+1] = '\0';
					break;
				}
			}
#endif
			return true;
		}
	
	}	
}