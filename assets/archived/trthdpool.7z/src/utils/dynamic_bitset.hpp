#pragma once
#include <vector>
#include <stddef.h>
namespace utils
{
	class dynamic_bitset
	{
		public:
			//相比于bitset/array 声明时不需要指定大小
			dynamic_bitset(size_t N)
			{
				m_size = N;
				m_bits.resize(N, 1);
				m_done_cnt = N;
			}

			bool any() const
			{
				for (size_t i = 0; i < m_size; ++i)
					if (m_bits[i])
						return true;
				return false;
			}

			bool any_blank() const 
			{
				for (size_t i = 0; i < m_size; ++i)
					if (!m_bits[i])
						return true;
				return false;
			}

			size_t set_done(size_t i)
			{
				bool prio = m_bits[i];
				m_bits[i] = 1;
				if (prio) return m_done_cnt;
				return ++m_done_cnt;
			}

			size_t set_done_range(size_t begin, size_t end)
			{
				size_t add_cnt = 0;
				for (size_t i = begin; i < end; i++)
				{
					bool prio = m_bits[i];
					m_bits[i] = 1;
					if (prio) continue;
					add_cnt++;
				}
				return m_done_cnt += add_cnt;
			}

			size_t done_cnt()
			{
				return m_done_cnt;
			}

			size_t find_first_done() const
			{
				for (size_t i = 0; i < m_size; ++i)
					if (m_bits[i])
						return i;
				return -1;
			}

			size_t find_first_blank() const 
			{
				for (size_t i = 0; i < m_size; ++i)
					if (!m_bits[i])
						return i;
				return -1;
			}

			size_t size()
			{
				return m_size;
			}

			virtual ~dynamic_bitset() {}

			std::vector<bool>* raw()
			{
				return &m_bits;
			}
		private:
			size_t m_size;
			size_t m_done_cnt;
			std::vector<bool> m_bits;
	};
}