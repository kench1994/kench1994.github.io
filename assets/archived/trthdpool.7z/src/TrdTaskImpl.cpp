#include "TrdPoolImpl.h"
#include <iostream>
using namespace tr::threadEx;

void ThreadPool::ThreadPoolImpl::thread_task_s::reset()
{
	c_excutor = NULL;
	heap_data_free = NULL;
	excutor_with_sp = NULL;

	work_excutor = nullptr;
	work_excutor_sp = nullptr;
	excutor_deleter = NULL;

	user_data_p = nullptr;
	user_data_sp = nullptr;

	can_steal = false;

	has_excuted = false;

	notify_on_destruction = false;
}

ThreadPool::ThreadPoolImpl::thread_task_s::~thread_task_s()
{
	if(has_excuted)
		return;

	if(notify_on_destruction)
	{
		//c
		if (NULL != c_excutor)
		{
			c_excutor(static_cast<uint8_t>(kTrdPoolError::unschedule), user_data_p);
		}
		//auto ptr
		else if (NULL != excutor_with_sp)
		{
			excutor_with_sp(static_cast<uint8_t>(kTrdPoolError::unschedule), user_data_sp);
		}
		//c++
		else if (nullptr != work_excutor)
		{
			work_excutor->routine(static_cast<uint8_t>(kTrdPoolError::unschedule));
		}
		//c++11
		else if (nullptr != work_excutor_sp)
		{
			work_excutor_sp->routine(static_cast<uint8_t>(kTrdPoolError::unschedule));
		}
	}
	

	//主要进行一些资源释放
	if (NULL != c_excutor && NULL != heap_data_free)
	{
		heap_data_free(user_data_p);
	}
	//c++
	else if (nullptr != work_excutor && NULL != excutor_deleter)
	{
		excutor_deleter(work_excutor);
	}
	has_excuted = true;
}

ThreadPool::ThreadPoolImpl::thread_task_s::thread_task_s(
  bool steal, bool destruction, \
  trThreadEx_CExcutor_t excutor, trThreadEx_FreeHeapData_t deleter, \
  void* user_data)
{
	reset();
	c_excutor = excutor;
	heap_data_free = deleter;
	user_data_p = user_data;
	can_steal = steal;
	notify_on_destruction = destruction;
}


ThreadPool::ThreadPoolImpl::thread_task_s::thread_task_s(
  bool steal, bool destruction, \
  trThreadEx_AutoExcutor_t excutor, const std::shared_ptr<void>& data_sp)
{
	reset();
	excutor_with_sp = excutor;
	//printf("use count %d\r\n", data_sp.use_count());
	user_data_sp = data_sp;
	//printf("use count %d\r\n", data_sp.use_count());
	can_steal = steal;
	notify_on_destruction = destruction;
}

ThreadPool::ThreadPoolImpl::thread_task_s::thread_task_s(bool steal, \
  bool destruction, IExcutor* excutor, trThreadEx_IExcutorDeleter_t deleter)
{
	reset();
	work_excutor = excutor;
	excutor_deleter = deleter;
	can_steal = steal;
	notify_on_destruction = destruction;
}

ThreadPool::ThreadPoolImpl::thread_task_s::thread_task_s(bool steal, \
  bool destruction, const std::shared_ptr<IExcutor>& excutor_sp)
{
	reset();
	work_excutor_sp = excutor_sp;
	can_steal = steal;
	notify_on_destruction = destruction;
}