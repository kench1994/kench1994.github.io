#pragma once
#include "utils/logger_prototype.h"
#include <stdio.h>
extern int g_hwndLogHandle;

extern dlplog_open_v2_t s_fn_dlplog_open_v2;
extern dlplog_t   s_fn_dlplog_debug;
extern dlplog_t   s_fn_dlplog_error;
extern dlplog_t    s_fn_dlplog_info;

inline int dlplog_open_v2(const char* log_name, char const* module_name)
{
	if(!s_fn_dlplog_open_v2)
		return 0;
	return s_fn_dlplog_open_v2(log_name, module_name);
}
#define dlplog_debug(log, fmt, ...) { \
	if(s_fn_dlplog_debug) \
	s_fn_dlplog_debug(log, fmt, ##__VA_ARGS__); \
}
#define dlplog_error(log, fmt, ...) {if(s_fn_dlplog_error)s_fn_dlplog_error(log, fmt, ##__VA_ARGS__);}

#define dlplog_info(log, fmt, ...) { \
	if(s_fn_dlplog_info) \
		s_fn_dlplog_info(log, fmt, ##__VA_ARGS__); \
}

