#pragma once
#include "trfclib/trthreadex/trthreadex.h"
#include "../interface/TrThreadPool.h"
#include "utils/dynamic_bitset.hpp"
#include "utils/block_queue.h"
#include "utils/logger_prototype.h"
#include "utils/library_utility.h"
#include <thread>
#include <memory>
#include <vector>
namespace tr
{
	namespace threadEx
	{
		class ThreadPool::ThreadPoolImpl
		{
		public:
			typedef struct thread_task_s
			{
				void reset();
				~thread_task_s();
				thread_task_s(bool can_steal, bool notify_on_destruction, trThreadEx_CExcutor_t excutor, trThreadEx_FreeHeapData_t deleter, void* data);
				thread_task_s(bool can_steal, bool notify_on_destruction, trThreadEx_AutoExcutor_t excutor, const std::shared_ptr<void>& user_data);
				thread_task_s(bool can_steal, bool notify_on_destruction, IExcutor* excutor, trThreadEx_IExcutorDeleter_t deleter);
				thread_task_s(bool can_steal, bool notify_on_destruction, const std::shared_ptr<IExcutor>& excutor);


				IExcutor* work_excutor;
				std::shared_ptr<IExcutor> work_excutor_sp;
				trThreadEx_IExcutorDeleter_t excutor_deleter;

				trThreadEx_CExcutor_t c_excutor;
				trThreadEx_FreeHeapData_t heap_data_free;
				trThreadEx_AutoExcutor_t excutor_with_sp;

				//user data 兼容指针和智能指针
				void* user_data_p;
				std::shared_ptr<void> user_data_sp;

				bool can_steal;
				//已经执行过
				bool has_excuted;

				bool notify_on_destruction;
			}ThreadTask_t;

			ThreadPoolImpl() = delete;
			ThreadPoolImpl(unsigned int pool_size, bool cpu_affinity, bool once_reactor);
			ThreadPoolImpl(ThreadPool&) = delete;
			ThreadPoolImpl& operator=(ThreadPool&) = delete;
			~ThreadPoolImpl();


			int initNotStart();

			int startUp();

			void stop();

			void release();

			template<class... Args>
			int submit(const TrdTaskOption_s* option, Args&&... args)
			{
				int  thread_idx = -1;
				bool immediately = false;
				bool can_steal = false;
				bool notify_on_destruction = false;
				if(option)
				{
					can_steal = option->can_steal;
					immediately = option->immediately;
					notify_on_destruction = option->notify_on_destruction;
					if(-1 != option->thread_idx)
						thread_idx = thread_idx % m_uPoolSize;
				}
				//未指定线程id,使用round-robin
				if(-1 == thread_idx)
				{
					tr::threadEx::tr_scopedlock_t lck(&m_mtxRoundRobin, true);
					thread_idx = m_nRoundRobinIdx++;
					if (m_uPoolSize == m_nRoundRobinIdx)
						m_nRoundRobinIdx = 0;
				}

				auto& task_queue = m_vWorkList[thread_idx];
				if(immediately)
					task_queue->emplace_front(std::make_shared<ThreadTask_t>(can_steal, notify_on_destruction, std::forward<Args>(args)...));
				else
					task_queue->emplace_back(std::make_shared<ThreadTask_t>(can_steal, notify_on_destruction, std::forward<Args>(args)...));
				return 0;
			}

		protected:
			void work(unsigned int idx);

			void task_excute(std::shared_ptr<ThreadTask_t>& spTask);

			/*打印lib信息*/
			void PrintLibInfo();

			/*加载日志组件*/
			void LoadLogComponent();

		private:
			unsigned int m_uPoolSize;

			bool m_bEnableCpuAffinity;

			bool m_bOnceReactor;

			using task_sptr_t = std::shared_ptr<ThreadTask_t>;
			using safe_task_que_sptr_t = std::shared_ptr<utils::concurrency_queue<task_sptr_t>>;

			//分发到哪个线程
			//使用round-bin算法时启用
			int m_nRoundRobinIdx;
			tr::threadEx::tr_quicklock_t m_mtxRoundRobin;

			/*工作标志*/
			tr::threadEx::tr_quicklock_t m_mtxWork;
			bool m_bWorking;
			bool m_bHasRelease;
			//线程池
			std::vector<std::thread> m_vThreadPool;
			//线程安全任务队列
			std::vector<safe_task_que_sptr_t> m_vWorkList;
			//work 线程 stop 视图(TODO:线程安全)
			std::shared_ptr<utils::dynamic_bitset> m_spTrdsStopedFlag;

			shared_library_t m_hLogLibrary;
		};
	}
}


