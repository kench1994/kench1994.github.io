#include "LogHelper.h"
#include <stddef.h>

dlplog_open_v2_t s_fn_dlplog_open_v2 = NULL;
dlplog_t   s_fn_dlplog_debug = NULL;
dlplog_t   s_fn_dlplog_error = NULL;
dlplog_t    s_fn_dlplog_info = NULL;