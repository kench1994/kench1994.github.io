#include "TrdPoolImpl.h"
#include "utils/path_utility.h"
#include "utils/str_utility.h"
#include "LogHelper.h"

using namespace tr::threadEx;

//日志句柄
int g_hwndLogHandle;

ThreadPool::ThreadPoolImpl::ThreadPoolImpl(unsigned int pool_size, bool cpu_affinity, bool once_reactor)
	: m_uPoolSize(pool_size)
	, m_bEnableCpuAffinity(cpu_affinity)
	, m_bOnceReactor(once_reactor)
	, m_bWorking(false)
	, m_bHasRelease(false)
	, m_spTrdsStopedFlag(nullptr)
	, m_nRoundRobinIdx(0)
	, m_hLogLibrary(NULL)
{
	LoadLogComponent();
	PrintLibInfo();
}

ThreadPool::ThreadPoolImpl::~ThreadPoolImpl()
{
	dlplog_debug(g_hwndLogHandle, "ThreadPoolImpl deconstruct");
	stop();
	release();
}

int ThreadPool::ThreadPoolImpl::initNotStart()
{
	auto uCurrPoolSize = m_vWorkList.size();
	if(uCurrPoolSize >= m_uPoolSize)
		return 0;
	for (unsigned int i = uCurrPoolSize; i < m_uPoolSize; i++)
	{
		m_vWorkList.emplace_back(std::make_shared<utils::concurrency_queue<task_sptr_t>>());
	}
	return 0;
}

int ThreadPool::ThreadPoolImpl::startUp()
{
	tr_scopedlock_t lck(&m_mtxWork, true);
	//reactor 可允许重入startup（不用重复申请直接复用）（但是没动作）
	if (m_bWorking && !m_bOnceReactor)
	{
		//TODO:LOG here
		return -1;
	}
	m_bWorking = true;
	lck.unlock();

	if (!m_spTrdsStopedFlag)
		m_spTrdsStopedFlag = std::make_shared<utils::dynamic_bitset>(m_uPoolSize);

	//const auto processor_count = std::thread::hardware_concurrency();

	for (unsigned int i = 0; i < m_uPoolSize; i++)
	{
		m_vThreadPool.emplace_back(std::bind(&ThreadPool::ThreadPoolImpl::work, this, i));
	}

	if(m_bOnceReactor)
	{
		for (auto& iter : m_vThreadPool)
		{
			if (iter.joinable())
				iter.join();
		}
		m_vThreadPool.clear();
	}

	return 0;
}

void ThreadPool::ThreadPoolImpl::stop()
{
	dlplog_debug(g_hwndLogHandle, "ThreadPoolImpl stop");
	tr_scopedlock_t lck(&m_mtxWork, true);
	//不让重复触发
	if (!m_bWorking)
		return;
	m_bWorking = false;
	lck.unlock();

	//通过每个工作线程的记录确保正常停止
	while (m_spTrdsStopedFlag->any_blank())
	{
		int n = m_spTrdsStopedFlag->find_first_blank();
		if(-1 == n)
			break;
		m_vWorkList[n]->notify_all();
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}

	//once reactor 自己跑起来就会清理pool
	if (m_bOnceReactor)
		return;

	for (auto& iter : m_vThreadPool)
	{
		if (iter.joinable())
			iter.join();
	}
}

void ThreadPool::ThreadPoolImpl::release()
{
	dlplog_debug(g_hwndLogHandle, "ThreadPoolImpl release");

	tr_scopedlock_t lck(&m_mtxWork, true);
	//不让重复触发
	if (m_bHasRelease)
		return;
	m_bHasRelease = true;
	lck.unlock();

	//丢弃所有任务
	for (auto& itQue : m_vWorkList)
		itQue->drain();

	std::vector<std::thread> empty_Pool;
	m_vThreadPool.swap(empty_Pool);
}

void ThreadPool::ThreadPoolImpl::work(unsigned int idx)
{
	bool is_idle = false;
#if defined(__GNUC__)
	if(m_bEnableCpuAffinity)
	{
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(idx % m_vThreadPool.size(), &cpuset);
		int rc = sched_setaffinity(m_vThreadPool[idx].native_handle(), sizeof(cpu_set_t), &cpuset);
		if (rc != 0)
			dlplog_debug(g_hwndLogHandle, "Error calling sched_setaffinity: %d", rc);
	}
#endif

	dlplog_debug(g_hwndLogHandle, "ThreadPoolImpl(0x%x) Enter Worker%d", this, idx);
	auto& origin_work_que = m_vWorkList[idx];
	m_spTrdsStopedFlag->set_done(idx);
	while (m_bWorking)
	{
		try
		{
			std::shared_ptr<ThreadTask_t> spTask{ nullptr };

			//once reactor
			if(m_bOnceReactor)
			{
				spTask = std::move(origin_work_que->pop_front());
				if(nullptr == spTask)
					break;
				task_excute(spTask);
				continue;
			}

			//steal working
			if(is_idle)
			{
				for (unsigned int n = 0; n < m_uPoolSize; ++n) 
				{
					spTask = std::move(m_vWorkList[idx]->try_pop_if(
						[](const task_sptr_t& task) { 
							return task->can_steal; 
					}));
					if(nullptr != spTask)
					{
						task_excute(spTask);
						break;
					}
				}
			}

			if(!m_bWorking)
				break;

			//origin work
			spTask = std::move(origin_work_que->wait_and_pop_t(3000));
			if (nullptr == spTask)
			{
				is_idle = true;
				continue;
			}
			is_idle = false;
			task_excute(spTask);
		}
		catch (const std::exception& e)
		{
			dlplog_error(g_hwndLogHandle, "ThreadWorker<%d> Caught Error:{%s}", idx, e.what());
		}
	}
	m_spTrdsStopedFlag->set_done(idx);

	dlplog_debug(g_hwndLogHandle,"ThreadPoolImpl(0x%x) Exit Worker%d", std::addressof(this), idx);
}

void ThreadPool::ThreadPoolImpl::task_excute(std::shared_ptr<ThreadTask_t> &spTask)
{
	try
	{
		//c
		if (NULL != spTask->c_excutor)
		{
			spTask->c_excutor(0, spTask->user_data_p);
			if (NULL != spTask->heap_data_free)
				spTask->heap_data_free(spTask->user_data_p);
		}
		//auto ptr
		else if (NULL != spTask->excutor_with_sp)
		{
			spTask->excutor_with_sp(0, spTask->user_data_sp);
		}
		//c++
		else if (nullptr != spTask->work_excutor)
		{
			spTask->work_excutor->routine(0);
			if (NULL != spTask->excutor_deleter)
				spTask->excutor_deleter(spTask->work_excutor);
		}
		//c++11
		else if (nullptr != spTask->work_excutor_sp)
		{
			spTask->work_excutor_sp->routine(0);
		}

		spTask->has_excuted = true;
		
	}catch(const std::exception& e)
	{
		throw e;
	}
}

void ThreadPool::ThreadPoolImpl::PrintLibInfo()
{
	dlplog_info(g_hwndLogHandle, "trThreadPool compile on %s %s", __DATE__, __TIME__);
}



void ThreadPool::ThreadPoolImpl::LoadLogComponent()
{
	int nRet = 0;
	char szLibpath[1024] {0x00};
	if(!utils::path::get_app_path(szLibpath, 1023))
	{
		fprintf(stderr, "获取程序路径失败\r\n");
		return;
	}
#if defined(_WIN32)
	utils::str::cross_sprintf(szLibpath + strlen(szLibpath), 1023 - strlen(szLibpath), "\\%s", "DlpULog.dll");
	m_hLogLibrary = ::LoadLibraryA(szLibpath);
#else
	utils::str::cross_sprintf(szLibpath + strlen(szLibpath), 1023 - strlen(szLibpath), "/libs_x64/%s", "libDlpULog.so");
	m_hLogLibrary = dlopen(szLibpath, RTLD_NOW);
#endif
    if( NULL == m_hLogLibrary ) return;

	s_fn_dlplog_open_v2 = (dlplog_open_v2_t)utils::shared_library::symbol_addr(m_hLogLibrary, "dlplog_open_v2");
	s_fn_dlplog_debug = (dlplog_t)utils::shared_library::symbol_addr(m_hLogLibrary, "dlplog_debug");
	s_fn_dlplog_error = (dlplog_t)utils::shared_library::symbol_addr(m_hLogLibrary, "dlplog_error");
	s_fn_dlplog_info = (dlplog_t)utils::shared_library::symbol_addr(m_hLogLibrary, "dlplog_info");

	if(0 >= (nRet = dlplog_open_v2("trThreadPool", "trThreadPool")))
	{
		fprintf(stderr, "加载日志组件失败");
        return;
	}
	g_hwndLogHandle = nRet;
}

