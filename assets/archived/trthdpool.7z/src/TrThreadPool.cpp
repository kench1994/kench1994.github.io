#include "../interface/TrThreadPool.h"
#include "TrdPoolImpl.h"
#include "LogHelper.h"

using namespace tr::threadEx;

ThreadPool::ThreadPool(const TrdPoolOption_s& opt)
    : m_pTrdPoolImpl(new ThreadPool::ThreadPoolImpl(opt.pool_size, opt.enable_cpu_affinity, opt.once_reactor_mode))
{
	dlplog_debug(g_hwndLogHandle, "ThreadPool construct");
}

ThreadPool::~ThreadPool()
{
	dlplog_debug(g_hwndLogHandle, "ThreadPool deconstruct");
    if(m_pTrdPoolImpl) 
	{
        stop();
        release();
        delete m_pTrdPoolImpl;
    }
}

int ThreadPool::initNotStart()
{
    if(!m_pTrdPoolImpl)		  
        return -1;
    return m_pTrdPoolImpl->initNotStart();
}

int ThreadPool::startUp()
{
    if(!m_pTrdPoolImpl)
        return -1;
    return m_pTrdPoolImpl->startUp();
}

void ThreadPool::stop()
{
    if(!m_pTrdPoolImpl)
        return;
    m_pTrdPoolImpl->stop();
}

void ThreadPool::release()
{
    if(!m_pTrdPoolImpl)
        return;
    m_pTrdPoolImpl->release();
}

int ThreadPool::submit(trThreadEx_CExcutor_t worker, \
	void* user_data,  trThreadEx_FreeHeapData_t free_allocator, \
	const TrdTaskOption_s* option \
)
{
	if(!m_pTrdPoolImpl)
		return -1;
	if(!worker)
		return -2;
	return m_pTrdPoolImpl->submit(option, worker, free_allocator, user_data);
}

int ThreadPool::submit_cxx(IExcutor* work_excutor, \
	trThreadEx_IExcutorDeleter_t excutor_deleter, \
	const TrdTaskOption_s* option \
)
{
	if(!m_pTrdPoolImpl)
		return -1;
	if(!work_excutor)
		return -2;
	return m_pTrdPoolImpl->submit(option, work_excutor, excutor_deleter);
}

int ThreadPool::submit_shared_data(trThreadEx_AutoExcutor_t worker, \
	std::shared_ptr<void> user_data, \
	const TrdTaskOption_s* option \
)
{
	if(!m_pTrdPoolImpl)
		return -1;
	if(!worker)
		return -2;
	return m_pTrdPoolImpl->submit(option, worker, user_data);
}

int ThreadPool::submit_shared_cxx(std::shared_ptr<IExcutor> work_excutor, \
	const TrdTaskOption_s* option \
)
{
	if(!m_pTrdPoolImpl)
		return -1;
	if(!work_excutor)
		return -2;
	return m_pTrdPoolImpl->submit(option, work_excutor);
}
